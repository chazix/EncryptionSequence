**** Look for "****#)" for instructions and guidelines

****1) Run EncryptionTechnique.exe
****2) For Cracking examples type in option 3 and press "enter"

 ----------------------
|  Input Options       |
 ----------------------
| 0 : Exit             |
| 1 : Factor Prime     |
| 2 : RSA Encryption   |
| 3 : Crack RSA Key    |
 ----------------------
: 3

****3) You will be prompted to choose whether you want to use a randomly generated
       public key (Option 1) with a given N, or input both a Public Key and an N
 ----------------------
|  Cracking   Options  |
 ----------------------
| 0 : Return To Main   |
|     Calc Private Key |
| 1 : Given N          |
| 2 : Given Public Key |
 ----------------------
:1

****4)Choosing option 1 and inputting a valid N will give the following output

=======================
Input the product of large primes (N)
: 25450261

Factoring N:

Found : 1024 Primes That May Make Up 25450261

Found Prime Factors : [p] = 5087 | [q] = 5003
Time Taken To Factor Prime : 0 seconds
Valid Public Key generated: 31243

Calculating Private Key...

Private Key found : 5765831

Press enter to continue... 
----------------------
|  Input Options       |
 ----------------------
| 0 : Exit             |
| 1 : Factor Prime     |
| 2 : RSA Encryption   |
| 3 : Crack RSA Key    |
 ----------------------
: 3
----------------------
|  Cracking   Options  |
 ----------------------
| 0 : Return To Main   |
|     Calc Private Key |
| 1 : Given N          |
| 2 : Given Public Key |
 ----------------------
:2

****5) Choosing option 2 and inputting a valid Public Key and N 
        will give the following output
=======================
Input Public Key (e)
:30809
Input the product of large primes (N)
:25450261
Factoring N:

Found : 1024 Primes That May Make Up 25450261

Found Prime Factors : [p] = 5087 | [q] = 5003
Time Taken To Factor Prime : 0 seconds

Calculating Private Key...

Private Key found : 18368549

Press enter to continue...
  1) Open Up EncryptionTechnique.exe  
  => Upon Opening The Program You Are Greeted With The Following Menu :
 
 ----------------------
|  Input Options       |
 ----------------------
| 0 : Exit             |
| 1 : Factor Prime     |
| 2 : RSA Encryption   |
| 3 : Crack RSA Key    |
 ----------------------
:2

1) Input 2 and press enter
2) Follow through Choosing Option 2 Example bellow for RSA Encryption

 ---------------------------
| Choosing Option 2 Example |
 ---------------------------
=======================
Input First Prime
:9817
Input Second Prime
:3299
 ----------------------
|  Encryption Options  |
 ----------------------
| 0 : Return To Main   |
| 1 : Run Cipher       |
 ----------------------
| PRIME 0 : 9817
| PRIME 1 : 3299
 ----------------------
:1
=======================
Input Data To Encrypt
:ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-=!@#$%^&*()_+:;",.? ~
=======================
| UNENCRYPTED INPUT DATA PADDED AT 2 DIGITS OF 2 |
102 | 304 | 506 | 708 | 910 | 1112 | 1314 | 1516 | 1718 | 1920 | 2122 | 2324 | 2526 | 2728 | 2930 | 3132 | 3334 | 3536 | 3738 | 3940 | 4142 | 4344 | 4546 | 4748 | 4950 | 5152 | 5354 | 5556 | 5758 | 
=======================
| ENCRYPT RESULTS |
6073830 | 14509714 | 18315121 | 25716830 | 13767684 | 21441996 | 28933591 | 8850437 | 308751 | 2291279 | 26087066 | 13363098 | 30241591 | 2127883 | 28275513 | 20308337 | 3760532 | 25635386 | 11075590 | 6089759 | 27567458 | 24697619 | 18400643 | 12516060 | 10737097 | 13598236 | 24518507 | 31507171 | 23449887 | 
=======================
| DECRYPT RESULTS |
ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-=!@#$%^&*()_+:;",.? ~
=======================

Press Enter To Continue
--------------------------
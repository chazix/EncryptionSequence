  1) Open Up EncryptionTechnique.exe  
  => Upon Opening The Program You Are Greeted With The Following Menu :
 
 ----------------------
|  Input Options       |
 ----------------------
| 0 : Exit             |
| 1 : Factor Prime     |
| 2 : RSA Encryption   |
| 3 : Crack RSA Key    |
 ----------------------
:1

1) Input 1 and press enter
2) Follow through Choosing Option 1 Example for Factoring Prime

 ---------------------------
| Choosing Option 1 Example |
 ---------------------------
Factoring => 25450261
----------------------------
: What Number Do You Want To Factor?
: 25450261
Found : 1024 Primes That May Make Up 25450261

Found Prime Factors : [p] = 5087 | [q] = 5003
Time Taken To Factor Prime : 0 seconds

Press Enter To Continue
--------------------------